# Taskplan - Frontend

> Hier ist das Fronted des Projektes das mit WPF umgesetzt worden ist.
> Dabei wird per API? die Daten manipuliert.
